import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EventvaluePage } from './eventvalue.page';

describe('EventvaluePage', () => {
  let component: EventvaluePage;
  let fixture: ComponentFixture<EventvaluePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EventvaluePage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EventvaluePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
