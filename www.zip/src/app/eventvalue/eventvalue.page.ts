import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eventvalue',
  templateUrl: './eventvalue.page.html',
  styleUrls: ['./eventvalue.page.scss'],
})
export class EventvaluePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
