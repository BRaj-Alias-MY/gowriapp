import { Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-childvalue',
  templateUrl: './childvalue.page.html',
  styleUrls: ['./childvalue.page.scss'],
})
export class ChildvaluePage {

  constructor() { }

  ngOnInit() {
  }

}
